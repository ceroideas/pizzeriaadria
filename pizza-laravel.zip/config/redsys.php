<?php
return [
    'key'                   => env('REDSYS_KEY',''),
    'url_notification'      => env('REDSYS_URL_NOTIFICATION',''),
    'url_ok'                => env('REDSYS_URL_OK',''),
    'url_ko'                => env('REDSYS_URL_KO',''),
    'merchantcode'          => env('REDSYS_MERCHANT_CODE',''),
    'terminal'              => env('REDSYS_TERMINAL','1'),
    'enviroment'            => env('REDSYS_ENVIROMENT','test'),
    'tradename'             => env('REDSYS_TRADENAME',''),
];
