<style>
	h4 {
		text-style: italic;
	}
</style>

<div style="display: none">
	{!! $form !!}
</div>

<h4>Redireccionando a redsys...</h4>


<script>document.forms["redsys_form"].submit();</script>