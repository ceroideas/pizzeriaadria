<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
	<title></title>
</head>
<body style="height: 500px; display: flex;">
	<h3>Ha habido un problema con el pago, contacte con la entidad correspondiente.</h3>
</body>
</html><?php /**PATH C:\xampp3\htdocs\pizza-laravel\resources\views/ko.blade.php ENDPATH**/ ?>