<style>
	h4 {
		text-style: italic;
	}
</style>

<div style="display: none">
	<?php echo $form; ?>

</div>

<h4>Redireccionando a redsys...</h4>


<script>document.forms["redsys_form"].submit();</script><?php /**PATH C:\xampp3\htdocs\pizza-laravel\resources\views/redsys.blade.php ENDPATH**/ ?>